package raytracer.math;

public final class Constants {

    public static final double TINY = 1E-3;
}
