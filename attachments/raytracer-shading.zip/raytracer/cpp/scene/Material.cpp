#include "Material.h"

Material::Material()
{
    //ctor
}
