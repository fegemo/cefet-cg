#include "Sphere.h"
#include <limits>
const double TINY = 1E-3;

Sphere::Sphere(Vector3 center, double radius) : Object::Object()
{
    //ctor
    this->center = center;
    this->radius = radius;
}

Sphere::~Sphere()
{
    //dtor
}

/**
 * *
 * Retorna um objeto do tipo RayResponse com informações sobre uma possível
 * interseção do raio com este objeto (veja o arquivo ray.h com a declaração
 * da struct RayResponse).
 *
 * O objeto response deve preencher os seguintes valores: -
 * response.intersected, true/false indicando se houve interseção ou não -
 * response.t, o valor T do raio (semi-reta) da primeira
 * interseção, caso haja mais que 1 interseção - response.Q,
 * contendo o ponto (x,y,z) de interseção - ray.normal, contendo
 * o vetor normal do objeto no ponto de interseção. A normal deve ser
 * *normalizada* (norma = 1)
 *
 */
RayResponse Sphere::intersectsWith(Ray& ray)
{
    Vector3 u = ray.u.normalized();
    Vector3 p = this->center - ray.P;
    double a = 1;
    double b = (-2) * u.dot(p);
    double c = p.dot(p) - pow(this->radius, 2);
    double delta = pow(b, 2) - 4*a*c;
    double root1, root2;
    bool hitFromInside = false;

    // Inicia uma resposta com um "intersects" falso,
    // indicando que não houve interseção
    RayResponse response =
    {
        false
    };

    if (delta < -TINY)
    {
        return response;
    }
    else if (delta > TINY)
    {
        // duas interseções - determinar qual foi a mais próxima
        root1 = (-b - sqrt(delta))/(2*a);
        root2 = (-b + sqrt(delta))/(2*a);
        if (root1 > TINY)
        {
            response.intersected = true;
            response.t = root1;
        }
        else if (root2 > TINY)
        {
            response.intersected = true;
            response.t = root2;
            hitFromInside = true;
        }
        else
        {
            return response;
        }
    }
    else
    {
        // uma interseção
        root1 = (-b + sqrt(delta))/2*a;
        if (root1 > TINY)
        {
            response.intersected = true;
            response.t = root1;
        }
        else
        {
            return response;
        }
    }

    response.Q = ray.P + (u * response.t);
    response.normal = (response.Q - this->center).normalized();
    if (hitFromInside)
    {
        response.normal = response.normal * -1;
    }

    return response;
}

Vector3 Sphere::getCenter()
{
    return center;
}

string Sphere::getGeometryName()
{
    return "sphere";
}
