#include "Light.h"

Light::Light()
{
    //ctor
}
