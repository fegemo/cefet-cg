#ifndef __INPUT_H__
#define __INPUT_H__

#include "../scene/Scene.h"

Scene loadSceneFromFile(const string& fileName);

#endif
